<?php
include("config.php");
include("class.php");
?>