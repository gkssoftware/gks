<?php
session_start();

define("SITE_NAME","spakshomeopathy.com");
define("SITE_PHONE","#");
define("SITE_MOBILE","0123 999 999");
define("SITE_EMAIL","info@spakshomeopathy.com");
define("SITE_URL","www.spakshomeopathy.com");
define("ADMIN_PATH","newadm");
define("BASE_URL", "http://www.spakshomeopathy.com");
define("PRICE_FORMAT", "$");



$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="shopcart";

try {
$conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass); 
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e) {
echo 'Connection failed: ' . $e->getMessage();
}


?>