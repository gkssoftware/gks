<?php
function protect_admin()
{
	if(empty($_SESSION['ADM_ID']))
	{
		echo "<script>window.location.href='login.php'</script>";
	}
}


function convert_to_slug($str) {
$str = strtolower(trim($str));
$str = preg_replace('/[^a-z0-9-]/', '-', $str);
$str = preg_replace('/-+/', "-", $str);
$str .= '-'.substr(md5(time()), 0, 5);
return rtrim($str, '-');
}


function create_url_slug($string){
   $slug=preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
   return $slug;
}

?>